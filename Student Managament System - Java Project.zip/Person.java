package StudentManagementSystem.src.model;

public abstract class Person {
    protected String name;
    protected String email;

    public Person(String name, String email) {
        this.name = name;
        this.email = email;
    }

    
    public abstract void displayInfo();

    
    public final void finalMethodExample() {
        System.out.println("This is a final method in Person class.");
    }

    
    @Override
    protected void finalize() throws Throwable {
        System.out.println("Finalize method called before object is garbage collected.");
    }
}
